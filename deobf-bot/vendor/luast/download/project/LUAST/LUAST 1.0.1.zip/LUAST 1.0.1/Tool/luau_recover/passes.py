from __future__ import annotations

import copy
import math
import struct
from dataclasses import dataclass, field
from typing import Any, Callable

from .analysis import Analyzer, Binding, analyze, binding_for, is_pure
from .model import Node, clone_value, iter_nodes, walk


UNKNOWN = object()


@dataclass
class PassStats:
    folded: int = 0
    propagated: int = 0
    pool_reads: int = 0
    pool_values: int = 0
    decoder_calls: int = 0
    branches_removed: int = 0
    dead_locals: int = 0
    dispatchers_found: int = 0
    dispatchers_removed: int = 0
    states_recovered: int = 0
    names_renamed: int = 0
    aliases_restored: int = 0
    errors: list[str] = field(default_factory=list)


def literal(node: Node | None) -> Any:
    if not isinstance(node, Node):
        return UNKNOWN
    if node.kind == "number":
        return node.get("value")
    if node.kind == "string":
        return node.get("value")
    if node.kind == "bool":
        return node.get("value")
    if node.kind == "nil":
        return None
    return UNKNOWN


def is_number(value: Any) -> bool:
    return isinstance(value, (int, float)) and not isinstance(value, bool)


def is_int(value: Any) -> bool:
    return isinstance(value, int) and not isinstance(value, bool)


def numeric_kind(value: Any) -> str | None:
    if is_int(value):
        return "int"
    if isinstance(value, float):
        return "float"
    return None


def value_node(value: Any) -> Node:
    if value is None:
        return Node("nil")
    if value is True:
        return Node("bool", value=True)
    if value is False:
        return Node("bool", value=False)
    if isinstance(value, bytes):
        return Node("string", value=value)
    if isinstance(value, str):
        return Node("string", value=value.encode("utf-8"))
    if isinstance(value, (int, float)):
        return Node("number", value=value)
    raise TypeError(type(value).__name__)


def truthy(value: Any) -> bool:
    return value is not UNKNOWN and value is not None and value is not False


def numeric_result(op: str, left: Any, right: Any) -> Any:
    if not is_number(left) or not is_number(right):
        return UNKNOWN
    if op in {"&", "|", "~", "<<", ">>"}:
        if not is_int(left) or not is_int(right):
            return UNKNOWN
        if op == "~":
            return left
        if op == "<<":
            return left << right if 0 <= right < 512 else UNKNOWN
        if op == ">>":
            return left >> right if right >= 0 else UNKNOWN
        return (left & right) if op == "&" else (left | right)
    if op == "+":
        return left + right
    if op == "-":
        return left - right
    if op == "*":
        return left * right
    if op == "/":
        if right == 0:
            if left == 0:
                return float("nan")
            return math.copysign(float("inf"), float(left)) * math.copysign(1.0, float(right))
        return float(left) / float(right)
    if op == "//":
        if right == 0:
            return UNKNOWN
        return left // right
    if op == "%":
        if right == 0:
            return UNKNOWN
        if isinstance(left, int) and isinstance(right, int):
            return left % right
        return math.fmod(left, right)
    if op == "^":
        try:
            result = left ** right
        except (OverflowError, ValueError, ZeroDivisionError):
            return UNKNOWN
        try:
            finite = math.isfinite(float(result))
        except (OverflowError, ValueError):
            finite = False
        return result if isinstance(result, (int, float)) and finite else UNKNOWN
    return UNKNOWN


def is_nan(value: Any) -> bool:
    return isinstance(value, float) and math.isnan(value)


def evaluate(node: Node | None, env: dict[int, Any] | None = None, analyzer: Analyzer | None = None) -> Any:
    if node is None:
        return UNKNOWN
    env = env or {}
    if node.kind == "paren":
        return evaluate(node.get("expr"), env, analyzer)
    if node.kind == "number" or node.kind == "string" or node.kind == "bool":
        return node.get("value")
    if node.kind == "nil":
        return None
    if node.kind == "name" and analyzer is not None:
        binding = binding_for(analyzer, node)
        if binding is not None and binding.ident in env:
            return env[binding.ident]
        return UNKNOWN
    if node.kind == "unop":
        value = evaluate(node.get("expr"), env, analyzer)
        if value is UNKNOWN:
            return UNKNOWN
        if node.get("op") == "not":
            return not truthy(value)
        if node.get("op") == "-" and is_number(value):
            return -value
        if node.get("op") == "#" and isinstance(value, bytes):
            return len(value)
        if node.get("op") == "~" and is_int(value):
            return ~value
        return UNKNOWN
    if node.kind == "binop":
        operator = node.get("op")
        if operator == "and":
            left = evaluate(node.get("left"), env, analyzer)
            if left is UNKNOWN:
                return UNKNOWN
            return evaluate(node.get("right"), env, analyzer) if truthy(left) else left
        if operator == "or":
            left = evaluate(node.get("left"), env, analyzer)
            if left is UNKNOWN:
                return UNKNOWN
            return left if truthy(left) else evaluate(node.get("right"), env, analyzer)
        left = evaluate(node.get("left"), env, analyzer)
        right = evaluate(node.get("right"), env, analyzer)
        if operator in {"==", "~=", "<", "<=", ">", ">="} and (is_nan(left) or is_nan(right)):
            return operator == "~="
        if left is UNKNOWN or right is UNKNOWN:
            return UNKNOWN
        if operator == "..":
            if isinstance(left, bytes) and isinstance(right, bytes):
                return left + right
            return UNKNOWN
        if operator in {"==", "~=", "<", "<=", ">", ">="}:
            if numeric_kind(left) != numeric_kind(right) and not (is_number(left) and is_number(right)):
                return UNKNOWN
            if not is_number(left) and type(left) is not type(right):
                return UNKNOWN
            try:
                if operator == "==":
                    return left == right
                if operator == "~=":
                    return left != right
                if operator == "<":
                    return left < right
                if operator == "<=":
                    return left <= right
                if operator == ">":
                    return left > right
                return left >= right
            except (TypeError, ValueError):
                return UNKNOWN
        return numeric_result(operator, left, right)
    if node.kind == "ifexpr":
        condition = evaluate(node.get("cond"), env, analyzer)
        if condition is UNKNOWN:
            return UNKNOWN
        if truthy(condition):
            return evaluate(node.get("then"), env, analyzer)
        for branch_condition, branch_value in node.get("elifs", []):
            branch_result = evaluate(branch_condition, env, analyzer)
            if branch_result is UNKNOWN:
                return UNKNOWN
            if truthy(branch_result):
                return evaluate(branch_value, env, analyzer)
        return evaluate(node.get("else_"), env, analyzer)
    return UNKNOWN


def transform_expr(node: Node, callback: Callable[[Node, bool], Node], target: bool = False) -> Node:
    kind = node.kind
    if kind == "binop":
        node.fields["left"] = transform_expr(node.get("left"), callback)
        node.fields["right"] = transform_expr(node.get("right"), callback)
    elif kind == "unop":
        node.fields["expr"] = transform_expr(node.get("expr"), callback)
    elif kind in ("paren", "typecast"):
        node.fields["expr"] = transform_expr(node.get("expr"), callback)
    elif kind == "call":
        node.fields["func"] = transform_expr(node.get("func"), callback)
        node.fields["args"] = [transform_expr(item, callback) for item in node.get("args", [])]
    elif kind == "methodcall":
        node.fields["obj"] = transform_expr(node.get("obj"), callback)
        node.fields["args"] = [transform_expr(item, callback) for item in node.get("args", [])]
    elif kind == "index":
        node.fields["obj"] = transform_expr(node.get("obj"), callback, target)
        node.fields["key"] = transform_expr(node.get("key"), callback, target)
    elif kind in ("indexname", "methodname"):
        node.fields["obj"] = transform_expr(node.get("obj"), callback)
    elif kind == "function":
        node.fields["body"] = transform_block(node.fields.get("body", []), callback)
    elif kind == "ifexpr":
        node.fields["cond"] = transform_expr(node.get("cond"), callback)
        node.fields["then"] = transform_expr(node.get("then"), callback)
        node.fields["elifs"] = [(transform_expr(condition, callback), transform_expr(value, callback)) for condition, value in node.get("elifs", [])]
        node.fields["else_"] = transform_expr(node.get("else_"), callback)
    elif kind == "table":
        items = []
        for key, value in node.get("items", []):
            new_key = key
            if key is not None and key.kind == "indexkey":
                new_key = key.clone()
                new_key.fields["key"] = transform_expr(key.get("key"), callback)
            items.append((new_key, transform_expr(value, callback)))
        node.fields["items"] = items
    else:
        for key, value in list(node.fields.items()):
            if isinstance(value, Node) and key not in {"raw", "type_text"}:
                if key in {"left", "right", "expr", "obj", "key", "func", "cond", "then", "else_"}:
                    node.fields[key] = transform_expr(value, callback)
        if kind == "ifexpr":
            node.fields["elifs"] = [(transform_expr(condition, callback), transform_expr(value, callback)) for condition, value in node.get("elifs", [])]
    return callback(node, target)


def transform_block(statements: list[Node], callback: Callable[[Node, bool], Node]) -> list[Node]:
    output: list[Node] = []
    for statement in statements:
        output.extend(transform_statement(statement, callback))
    return output


def transform_statement(node: Node, callback: Callable[[Node, bool], Node]) -> list[Node]:
    kind = node.kind
    if kind == "local":
        node.fields["values"] = [transform_expr(value, callback) for value in node.get("values", [])]
    elif kind == "localfunc":
        node.fields["body"] = transform_block(node.fields.get("body", []), callback)
    elif kind == "funcdef":
        node.fields["target"] = transform_expr(node.get("target"), callback, True)
        node.fields["body"] = transform_block(node.fields.get("body", []), callback)
    elif kind == "assign":
        node.fields["targets"] = [transform_expr(value, callback, True) for value in node.get("targets", [])]
        node.fields["values"] = [transform_expr(value, callback) for value in node.get("values", [])]
    elif kind in ("call", "methodcall"):
        transform_expr(node, callback)
    elif kind == "if":
        node.fields["cond"] = transform_expr(node.get("cond"), callback)
        node.fields["then"] = transform_block(node.get("then", []), callback)
        node.fields["elifs"] = [(transform_expr(condition, callback), transform_block(body, callback)) for condition, body in node.get("elifs", [])]
        node.fields["else_"] = transform_block(node.get("else_", []), callback)
    elif kind == "while":
        node.fields["cond"] = transform_expr(node.get("cond"), callback)
        node.fields["body"] = transform_block(node.get("body", []), callback)
    elif kind == "repeat":
        node.fields["body"] = transform_block(node.get("body", []), callback)
        node.fields["cond"] = transform_expr(node.get("cond"), callback)
    elif kind == "fornum":
        for key in ("start_expr", "limit", "step"):
            if node.get(key) is not None:
                node.fields[key] = transform_expr(node.get(key), callback)
        node.fields["body"] = transform_block(node.get("body", []), callback)
    elif kind == "forin":
        node.fields["iterators"] = [transform_expr(value, callback) for value in node.get("iterators", [])]
        node.fields["body"] = transform_block(node.get("body", []), callback)
    elif kind == "do":
        node.fields["body"] = transform_block(node.get("body", []), callback)
    elif kind == "return":
        node.fields["values"] = [transform_expr(value, callback) for value in node.get("values", [])]
    elif kind in ("break", "continue", "goto", "label", "opaque"):
        return [node]
    else:
        transform_expr(node, callback)
    transformed = callback(node, False)
    if isinstance(transformed, Node) and transformed.kind == "_removed":
        return []
    return [transformed] if isinstance(transformed, Node) else []


def constant_environment(analyzer: Analyzer) -> dict[int, Any]:
    result: dict[int, Any] = {}
    for node in walk(analyzer.root):
        if not isinstance(node, Node) or node.kind != "local":
            continue
        bindings = analyzer.declaration_bindings.get(id(node), [])
        values = node.get("values", [])
        for binding, value in zip(bindings, values):
            if binding.writes != 0:
                continue
            evaluated = literal(value)
            if evaluated is not UNKNOWN:
                result[binding.ident] = evaluated
    return result


def fold_constants(root: Node, analyzer: Analyzer, stats: PassStats, rounds: int = 4) -> Node:
    for _ in range(rounds):
        environment = constant_environment(analyzer)
        changed = [False]

        def callback(node: Node, target: bool) -> Node:
            if target:
                return node
            if node.kind == "if":
                condition = evaluate(node.get("cond"), environment, analyzer)
                if condition is not UNKNOWN:
                    selected: list[Node] = []
                    if truthy(condition):
                        selected = node.get("then", [])
                    else:
                        for branch_condition, branch_body in node.get("elifs", []):
                            branch_value = evaluate(branch_condition, environment, analyzer)
                            if branch_value is not UNKNOWN and truthy(branch_value):
                                selected = branch_body
                                break
                        else:
                            selected = node.get("else_", [])
                    changed[0] = True
                    stats.branches_removed += 1
                    return Node("do", node.start, node.end, body=selected)
                return node
            if node.kind in {"number", "string", "bool", "nil", "name", "vararg", "interpolated", "opaque"}:
                return node
            result = evaluate(node, environment, analyzer)
            if result is not UNKNOWN:
                replacement = value_node(result)
                replacement.start = node.start
                replacement.end = node.end
                stats.folded += 1
                changed[0] = True
                return replacement
            return node

        root.fields["body"] = transform_block(root.get("body", []), callback)
        if not changed[0]:
            break
    return root


def propagate_locals(root: Node, analyzer: Analyzer, stats: PassStats) -> Node:
    environment = constant_environment(analyzer)

    def callback(node: Node, target: bool) -> Node:
        if target or node.kind != "name":
            return node
        binding = binding_for(analyzer, node)
        if binding is None or binding.ident not in environment:
            return node
        replacement = value_node(environment[binding.ident])
        replacement.start = node.start
        replacement.end = node.end
        stats.propagated += 1
        return replacement

    root.fields["body"] = transform_block(root.get("body", []), callback)
    return root


def restore_library_aliases(root: Node, analyzer: Analyzer, stats: PassStats) -> Node:
    allowed = {"bit32", "buffer", "math", "os", "string", "table", "task", "coroutine", "utf8"}
    aliases: dict[int, Node] = {}
    for node in walk(root):
        if not isinstance(node, Node) or node.kind != "local":
            continue
        bindings = analyzer.declaration_bindings.get(id(node), [])
        values = node.get("values", [])
        if len(bindings) != 1 or len(values) != 1 or bindings[0].writes:
            continue
        value = values[0]
        if value.kind != "indexname":
            continue
        base = value.get("obj")
        if isinstance(base, Node) and base.kind == "name" and base.get("name") in allowed:
            aliases[bindings[0].ident] = value.clone()
    if not aliases:
        return root

    def callback(node: Node, target: bool) -> Node:
        if target or node.kind != "name":
            return node
        binding = binding_for(analyzer, node)
        if binding is None or binding.ident not in aliases:
            return node
        stats.aliases_restored += 1
        return aliases[binding.ident].clone()

    root.fields["body"] = transform_block(root.get("body", []), callback)
    return root


def remove_unused_locals(root: Node, analyzer: Analyzer, stats: PassStats) -> Node:
    def process(statements: list[Node]) -> list[Node]:
        output: list[Node] = []
        for statement in statements:
            if statement.kind == "local":
                bindings = analyzer.declaration_bindings.get(id(statement), [])
                values = statement.get("values", [])
                if len(bindings) == 1 and len(statement.get("names", [])) == 1:
                    binding = bindings[0]
                    if binding.reads == 0 and binding.writes == 0 and all(is_pure(value) for value in values):
                        stats.dead_locals += 1
                        continue
            if statement.kind == "if":
                statement.fields["then"] = process(statement.get("then", []))
                statement.fields["elifs"] = [(condition, process(body)) for condition, body in statement.get("elifs", [])]
                statement.fields["else_"] = process(statement.get("else_", []))
            elif statement.kind in {"while", "repeat", "do"}:
                statement.fields["body"] = process(statement.get("body", []))
            elif statement.kind in {"fornum", "forin"}:
                statement.fields["body"] = process(statement.get("body", []))
            elif statement.kind in {"localfunc", "funcdef", "function"}:
                statement.fields["body"] = process(statement.get("body", []))
            output.append(statement)
        return output

    root.fields["body"] = process(root.get("body", []))
    return root


@dataclass
class BufferValue:
    data: bytes


class PoolResolver:
    def __init__(self, root: Node, analyzer: Analyzer, source: str, allow_escape: bool = False):
        self.root = root
        self.analyzer = analyzer
        self.source = source
        self.allow_escape = allow_escape
        self.roots: dict[int, Node] = {}
        self.aliases: dict[int, int] = {}
        self.declaration_start: dict[int, int] = {}
        self.events: list[tuple[int, int, Node, Node, bool]] = []
        self.reads: list[Node] = []
        self.statement_nodes: set[int] = set()
        self.parents: dict[int, Node] = {}
        self.targets: set[int] = set()
        self.value_nodes: dict[int, Node] = {}
        self.replacements: dict[int, Node] = {}
        self.local_values: dict[int, Any] = {}
        self.base_states: dict[int, dict[tuple[Any, ...], Node]] = {}
        self.invalid_after: int | None = None
        self.decoder_cache: dict[int, str | None] = {}
        self.safe = True
        self.discover()

    def invalidate(self, position: int) -> None:
        if self.invalid_after is None or position < self.invalid_after:
            self.invalid_after = position
        if not self.allow_escape:
            self.safe = False

    def discover(self) -> None:
        for node in walk(self.root):
            if node.kind != "local":
                continue
            bindings = self.analyzer.declaration_bindings.get(id(node), [])
            values = node.get("values", [])
            if len(bindings) == 1 and len(values) == 1 and values[0].kind == "table":
                self.roots[bindings[0].ident] = values[0]
                self.declaration_start[bindings[0].ident] = node.end
            elif len(bindings) == 1 and len(values) == 1 and values[0].kind == "name":
                source_binding = binding_for(self.analyzer, values[0])
                if source_binding is not None:
                    self.aliases[bindings[0].ident] = source_binding.ident
        use_positions: dict[int, int] = {}
        for node in walk(self.root):
            if node.kind != "name":
                continue
            binding = binding_for(self.analyzer, node)
            if binding is not None:
                use_positions[binding.ident] = min(use_positions.get(binding.ident, node.start), node.start)
        for node in walk(self.root):
            if node.kind != "assign" or len(node.get("targets", [])) != 1 or len(node.get("values", [])) != 1:
                continue
            target = node.get("targets", [])[0]
            value = node.get("values", [])[0]
            if target.kind != "name" or value.kind != "table":
                continue
            binding = binding_for(self.analyzer, target)
            if binding is None or binding.ident in self.roots:
                continue
            declaration = binding.declaration
            if isinstance(declaration, Node) and declaration.kind == "local":
                names = declaration.get("names", [])
                first_use = use_positions.get(binding.ident)
                if binding.name in names and len(declaration.get("values", [])) == 0 and (first_use is None or first_use >= node.start):
                    self.roots[binding.ident] = value
                    self.declaration_start[binding.ident] = value.end
        changed = True
        while changed:
            changed = False
            for alias, target in list(self.aliases.items()):
                if target in self.aliases:
                    self.aliases[alias] = self.aliases[target]
                    changed = True
        for node in walk(self.root):
            if node.kind == "assign":
                targets = node.get("targets", [])
                values = node.get("values", [])
                if targets and len(targets) != len(values):
                    if any(target.kind == "index" for target in targets):
                        self.invalidate(node.start)
                for target_index, target in enumerate(targets):
                    self.targets.add(id(target))
                    if target.kind != "index":
                        continue
                    base = target.get("obj")
                    if not isinstance(base, Node) or base.kind != "name":
                        continue
                    binding = binding_for(self.analyzer, base)
                    if binding is None:
                        continue
                    root_id = self.aliases.get(binding.ident, binding.ident)
                    if root_id not in self.roots:
                        continue
                    key = literal(target.get("key"))
                    if key is UNKNOWN:
                        self.invalidate(node.start)
                        continue
                    if target_index >= len(values):
                        self.invalidate(node.start)
                        continue
                    self.events.append((node.start, node.end, target, values[target_index], True))
            if node.kind == "index":
                base = node.get("obj")
                if isinstance(base, Node) and base.kind == "name":
                    binding = binding_for(self.analyzer, base)
                    if binding is not None:
                        root_id = self.aliases.get(binding.ident, binding.ident)
                        if root_id in self.roots and id(node) not in self.targets:
                            self.reads.append(node)
        self.reads.sort(key=lambda item: item.start)
        self.events.sort(key=lambda item: item[0])
        self.parents = self.parent_map()
        for node in walk(self.root):
            if node.kind != "name":
                continue
            binding = binding_for(self.analyzer, node)
            if binding is None:
                continue
            root_id = self.aliases.get(binding.ident, binding.ident)
            if root_id not in self.roots:
                continue
            if id(node) in self.targets:
                continue
            parent = self.parents.get(id(node))
            if parent is not None and parent.kind == "index" and parent.get("obj") is node:
                continue
            if parent is not None and parent.kind == "local" and node in parent.get("values", []):
                continue
            if parent is not None and parent.kind == "assign" and node in parent.get("targets", []):
                continue
            if not self.allow_escape:
                self.safe = False
                break
        for node in walk(self.root):
            for key in ("body", "then", "else_"):
                value = node.fields.get(key)
                if isinstance(value, list):
                    self.statement_nodes.update(id(item) for item in value if isinstance(item, Node))
            for _, body in node.fields.get("elifs", []):
                if isinstance(body, list):
                    self.statement_nodes.update(id(item) for item in body if isinstance(item, Node))

    def parent_map(self) -> dict[int, Node]:
        result: dict[int, Node] = {}
        for node in walk(self.root):
            for value in node.fields.values():
                if isinstance(value, Node):
                    result[id(value)] = node
                elif isinstance(value, (list, tuple)):
                    for item in value:
                        if isinstance(item, Node):
                            result[id(item)] = node
                        elif isinstance(item, (list, tuple)):
                            for nested in item:
                                if isinstance(nested, Node):
                                    result[id(nested)] = node
        return result

    def is_object_position(self, node: Node) -> bool:
        current = node
        for _ in range(16):
            parent = self.parents.get(id(current))
            if parent is None:
                return False
            if parent.kind in {"index", "indexname", "methodcall"} and parent.get("obj") is current:
                return True
            if parent.kind == "index" and parent.get("obj") is current:
                return True
            return False
        return False

    def is_callee_position(self, node: Node) -> bool:
        current = node
        for _ in range(16):
            parent = self.parents.get(id(current))
            if parent is None:
                return False
            if parent.kind == "call" and parent.get("func") is current:
                return True
            if parent.kind == "methodcall" and parent.get("obj") is current:
                return True
            if parent.kind == "index" and parent.get("obj") is current:
                current = parent
                continue
            if parent.kind == "indexname" and parent.get("obj") is current:
                current = parent
                continue
            return False
        return False

    def root_for(self, node: Node) -> int | None:
        if node.kind != "name":
            return None
        binding = binding_for(self.analyzer, node)
        if binding is None:
            return None
        root_id = self.aliases.get(binding.ident, binding.ident)
        return root_id if root_id in self.roots else None

    def key_for(self, node: Node | None) -> tuple[Any, ...] | None:
        value = literal(node)
        if value is UNKNOWN:
            return None
        if value is None:
            return ("nil",)
        if isinstance(value, bool):
            return ("bool", value)
        if isinstance(value, int):
            return ("number", value)
        if isinstance(value, float):
            if not math.isfinite(value) or not value.is_integer():
                return None
            return ("number", int(value))
        if isinstance(value, bytes):
            return ("string", value)
        return None

    def initial_state(self, root_id: int) -> dict[tuple[Any, ...], Node]:
        table = self.roots[root_id]
        result: dict[tuple[Any, ...], Node] = {}
        array_index = 1
        for key, value in table.get("items", []):
            if key is None:
                result[("number", array_index)] = value
                array_index += 1
            elif key.kind == "namekey":
                result[("string", key.get("name", "").encode("utf-8"))] = value
            else:
                literal_key = self.key_for(key.get("key"))
                if literal_key is not None:
                    result[literal_key] = value
        return result

    def resolve_value(self, node: Node, state: dict[tuple[Any, ...], Node], seen: set[int] | None = None) -> Node | None:
        seen = set() if seen is None else seen
        if id(node) in seen:
            return None
        seen.add(id(node))
        if node.kind == "index":
            key = self.key_for(node.get("key"))
            if key is None:
                return None
            base = node.get("obj")
            if isinstance(base, Node) and base.kind == "name":
                root_id = self.root_for(base)
                if root_id is not None and key in state:
                    return state[key]
                if self.allow_escape and root_id is not None:
                    fallback = self.base_states.get(root_id, {})
                    if key in fallback:
                        return fallback[key]
            base_value = self.resolve_value(base, state, seen) if isinstance(base, Node) else None
            if base_value is not None and base_value.kind == "table":
                table_state = self.initial_state_for_table(base_value)
                return table_state.get(key)
            return None
        return None

    def initial_state_for_table(self, table: Node) -> dict[tuple[Any, ...], Node]:
        result: dict[tuple[Any, ...], Node] = {}
        index = 1
        for key, value in table.get("items", []):
            if key is None:
                result[("number", index)] = value
                index += 1
            elif key.kind == "namekey":
                result[("string", key.get("name", "").encode("utf-8"))] = value
            else:
                literal_key = self.key_for(key.get("key"))
                if literal_key is not None:
                    result[literal_key] = value
        return result

    def event_value(self, node: Node, state: dict[tuple[Any, ...], Node]) -> Node:
        direct = self.resolve_value(node, state) if node.kind == "index" else None
        if direct is not None:
            return direct
        if node.kind == "name":
            binding = binding_for(self.analyzer, node)
            if binding is not None:
                return node
        return node

    def build_replacements(self, stats: PassStats) -> None:
        if not self.safe:
            return
        states = {root_id: self.initial_state(root_id) for root_id in self.roots}
        self.base_states = {root_id: dict(state) for root_id, state in states.items()}
        grouped: dict[int, list[tuple[int, int, Node, Node, bool]]] = {}
        for event in self.events:
            grouped.setdefault(event[0], []).append(event)
        event_starts = sorted(grouped)
        event_index = 0
        for read in self.reads:
            while event_index < len(event_starts) and event_starts[event_index] < read.start:
                start = event_starts[event_index]
                pending: list[tuple[int, tuple[Any, ...], Node]] = []
                for _, _, target, event_rhs, _ in grouped[start]:
                    base = target.get("obj")
                    root_id = self.root_for(base) if isinstance(base, Node) else None
                    key = self.key_for(target.get("key"))
                    if root_id is None or key is None:
                        continue
                    pending.append((root_id, key, self.event_value(event_rhs, states[root_id])))
                for root_id, key, resolved in pending:
                    states[root_id][key] = resolved
                event_index += 1
            base = read.get("obj")
            root_id = self.root_for(base) if isinstance(base, Node) else None
            resolved = self.resolve_value(read, states[root_id]) if root_id is not None else None
            if resolved is None:
                continue
            value = literal(resolved)
            if value is None:
                continue
            if id(read) in self.statement_nodes:
                continue
            self.value_nodes[id(read)] = resolved
            if self.is_callee_position(read) or self.is_object_position(read):
                continue
            if value is not UNKNOWN:
                self.replacements[id(read)] = value_node(value)
                stats.pool_reads += 1
        stats.pool_values += len(self.replacements)
        self.build_local_values()

    def build_local_values(self) -> None:
        declarations: list[Node] = []
        for node in walk(self.root):
            if node.kind == "local" or (node.kind == "assign" and len(node.get("targets", [])) == 1 and len(node.get("values", [])) == 1):
                declarations.append(node)
        declarations.sort(key=lambda item: item.start)
        for node in declarations:
            if node.kind == "local":
                bindings = self.analyzer.declaration_bindings.get(id(node), [])
                values = node.get("values", [])
                if len(bindings) != 1 or len(values) != 1:
                    continue
                binding = bindings[0]
            else:
                target = node.get("targets", [])[0]
                if target.kind != "name":
                    continue
                binding = binding_for(self.analyzer, target)
                if binding is None:
                    continue
                values = node.get("values", [])
            try:
                value = self.static_eval(values[0], None, 0)
            except (ArithmeticError, TypeError, ValueError, OverflowError):
                continue
            if value is not UNKNOWN:
                self.local_values[binding.ident] = value

    def decoder_formula(self, node: Node) -> str | None:
        identity = id(node)
        if identity in self.decoder_cache:
            return self.decoder_cache[identity]
        text = self.source[node.start:node.end]
        if "16843009" in text or "0x01010101" in text.lower() or "16711935" in text:
            formula = "xor"
        elif "1597" in text and "51749" in text:
            formula = "lcg"
        elif "2654435769" in text and "16807" in text:
            formula = "park"
        elif "2654435769" in text:
            formula = "golden"
        else:
            formula = None
        self.decoder_cache[identity] = formula
        return formula

    def dotted_name(self, node: Node | None) -> str | None:
        if not isinstance(node, Node):
            return None
        if node.kind == "name":
            return node.get("name")
        if node.kind == "indexname":
            base = self.dotted_name(node.get("obj"))
            return base + "." + node.get("name", "") if base else None
        return None

    def static_eval(self, node: Node | None, state: dict[tuple[Any, ...], Node] | None = None, depth: int = 0) -> Any:
        if node is None or depth > 32:
            return UNKNOWN
        direct = literal(node)
        if direct is not UNKNOWN:
            return direct
        if node.kind == "name":
            binding = binding_for(self.analyzer, node)
            if binding is not None and binding.ident in self.local_values:
                return self.local_values[binding.ident]
            return UNKNOWN
        if node.kind == "index":
            resolved = self.value_nodes.get(id(node))
            if resolved is not None and resolved is not node:
                value = literal(resolved)
                if value is not UNKNOWN:
                    return value
                if resolved.kind == "table":
                    return resolved
            return UNKNOWN
        if node.kind == "paren":
            return self.static_eval(node.get("expr"), state, depth + 1)
        if node.kind == "unop":
            value = self.static_eval(node.get("expr"), state, depth + 1)
            if value is UNKNOWN:
                return UNKNOWN
            if node.get("op") == "not":
                return not truthy(value)
            if node.get("op") == "-" and is_number(value):
                return -value
            if node.get("op") == "#" and (isinstance(value, bytes) or isinstance(value, BufferValue)):
                return len(value.data) if isinstance(value, BufferValue) else len(value)
            return UNKNOWN
        if node.kind == "binop":
            operator = node.get("op")
            left = self.static_eval(node.get("left"), state, depth + 1)
            right = self.static_eval(node.get("right"), state, depth + 1)
            if left is UNKNOWN or right is UNKNOWN:
                return UNKNOWN
            if operator == "and":
                return right if truthy(left) else left
            if operator == "or":
                return left if truthy(left) else right
            if operator == "..":
                return left + right if isinstance(left, bytes) and isinstance(right, bytes) else UNKNOWN
            if operator in {"==", "~=", "<", "<=", ">", ">="}:
                if is_nan(left) or is_nan(right):
                    return operator == "~="
                if numeric_kind(left) != numeric_kind(right) and not (is_number(left) and is_number(right)):
                    return UNKNOWN
                try:
                    return {"==": left == right, "~=": left != right, "<": left < right, "<=": left <= right, ">": left > right, ">=": left >= right}[operator]
                except (TypeError, ValueError):
                    return UNKNOWN
            return numeric_result(operator, left, right)
        if node.kind == "call":
            return self.static_call(node, state, depth)
        return UNKNOWN

    def static_call(self, node: Node, state: dict[tuple[Any, ...], Node] | None, depth: int) -> Any:
        function_value = self.value_nodes.get(id(node.get("func")))
        derived_name = self.dotted_name(node.get("func"))
        if isinstance(function_value, Node) and function_value.kind in {"name", "indexname"}:
            derived_name = self.dotted_name(function_value) or derived_name
        if isinstance(function_value, Node) and function_value.kind == "function":
            formula = self.decoder_formula(function_value)
            if formula and len(node.get("args", [])) >= 2:
                args = [self.static_eval(arg, state, depth + 1) for arg in node.get("args", [])]
                if len(args) >= 2 and (isinstance(args[0], bytes) or isinstance(args[0], BufferValue)) and is_int(args[1]):
                    cipher = args[0].data if isinstance(args[0], BufferValue) else args[0]
                    trim = args[2] if len(args) > 2 and is_int(args[2]) else 0
                    if 0 <= trim <= len(cipher):
                        if formula == "xor":
                            return xor_decode(cipher, args[1], trim)
                        if formula == "golden":
                            return golden_xor_decode(cipher, args[1], trim)
                        if formula == "lcg":
                            return lcg_subtract_decode(cipher, args[1], trim)
                        if formula == "park":
                            return park_xor_decode(cipher, args[1], trim)
        args = [self.static_eval(argument, state, depth + 1) for argument in node.get("args", [])]
        return builtin_call(derived_name, args)

    def apply(self, root: Node, stats: PassStats) -> Node:
        self.build_replacements(stats)
        if not self.replacements and not self.value_nodes:
            return root

        def callback(node: Node, target: bool) -> Node:
            if target:
                return node
            if node.kind == "call":
                result = self.static_call(node, None, 0)
                if result is not UNKNOWN and isinstance(result, (bytes, str, int, float, bool)) or result is None:
                    stats.decoder_calls += 1
                    return value_node(result)
            replacement = self.replacements.get(id(node))
            if replacement is not None and node.kind == "index":
                if replacement.kind == "function":
                    return node
                stats.pool_reads += 0
                return replacement.clone()
            return node

        root.fields["body"] = transform_block(root.get("body", []), callback)
        return root


def xor_decode(data: bytes, key: int, trim: int = 0) -> bytes:
    end = max(0, len(data) - trim)
    repeated = (key & 0xFF) * 0x01010101
    output = bytearray()
    for offset in range(0, end - end % 4, 4):
        word = int.from_bytes(data[offset:offset + 4], "little") ^ (repeated & 0xFFFFFFFF)
        output.extend(word.to_bytes(4, "little"))
    for index in range(len(output), end):
        output.append(data[index] ^ (key & 0xFF))
    return bytes(output)


def _u32(value: int) -> int:
    return value & 0xFFFFFFFF


def _rol32(value: int, amount: int) -> int:
    amount %= 32
    value = _u32(value)
    return _u32((value << amount) | (value >> (32 - amount))) if amount else value


def avalanche_hash(value: int) -> int:
    value = _u32(value)
    for add, right, left, rotate in (
        (2654435769, 16, 5, 11), (2246822507, 13, 9, 19),
        (3266489909, 15, 7, 23), (668265263, 17, 11, 13),
        (374761393, 11, 13, 7), (4283543511, 14, 6, 17),
    ):
        value = _u32(value + add)
        value = _u32(value ^ (value >> right))
        value = _u32(value ^ (value << left))
        value = _rol32(value, rotate)
    return value


def golden_xor_decode(data: bytes, seed: int, trim: int = 0) -> bytes:
    end = max(0, len(data) - trim)
    state = _u32(seed)
    output = bytearray(data)
    offset = 0
    while offset + 4 <= end:
        state = _u32(state + 2654435769)
        word = int.from_bytes(data[offset:offset + 4], "little") ^ state
        output[offset:offset + 4] = _u32(word).to_bytes(4, "little")
        offset += 4
    if offset < end:
        state = _u32(state + 2654435769)
        for index in range(offset, end):
            output[index] = (data[index] ^ ((state >> (8 * (index - offset))) & 0xFF)) & 0xFF
    return bytes(output[:end])


def lcg_subtract_decode(data: bytes, seed: int, trim: int = 0) -> bytes:
    end = max(0, len(data) - trim)
    state = _u32(seed)
    output = bytearray(data)
    offset = 0
    while offset + 4 <= end:
        state = _u32(state * 1597 + 51749)
        word = (int.from_bytes(data[offset:offset + 4], "little") - state) & 0xFFFFFFFF
        output[offset:offset + 4] = word.to_bytes(4, "little")
        offset += 4
    if offset < end:
        state = _u32(state * 1597 + 51749)
        for index in range(offset, end):
            output[index] = (data[index] - ((state >> (8 * (index - offset))) & 0xFF)) & 0xFF
    return bytes(output[:end])


def park_xor_decode(data: bytes, seed: int, trim: int = 0) -> bytes:
    end = max(0, len(data) - trim)
    state = avalanche_hash(seed) % 2147483646 + 1
    state = (state * 16807) % 2147483647
    output = bytearray(data)
    for offset in range(0, end - (end % 4), 4):
        word = int.from_bytes(data[offset:offset + 4], "little") ^ state
        output[offset:offset + 4] = _u32(word).to_bytes(4, "little")
    for index in range(end - (end % 4), end):
        lane = (state >> (8 * (index - (end - (end % 4))))) & 0xFF
        output[index] = data[index] ^ lane
    return bytes(output[:end])


def builtin_call(name: str | None, args: list[Any]) -> Any:
    if name is None:
        return UNKNOWN
    if name == "string.byte" and args and isinstance(args[0], bytes):
        start = int(args[1]) if len(args) > 1 and is_int(args[1]) else 1
        if start < 1 or start > len(args[0]):
            return UNKNOWN
        return args[0][start - 1]
    if name == "string.char" and args and all(is_int(value) and 0 <= value <= 255 for value in args):
        return bytes(args)
    if name == "tostring" and len(args) == 1 and isinstance(args[0], bytes):
        return args[0]
    if name == "buffer.fromstring" and len(args) == 1 and isinstance(args[0], bytes):
        return BufferValue(args[0])
    if name == "buffer.readstring" and len(args) >= 2 and isinstance(args[0], BufferValue):
        offset = args[1]
        length = args[2] if len(args) > 2 else len(args[0].data) - offset
        if not is_int(offset) or not is_int(length) or offset < 0 or length < 0 or offset + length > len(args[0].data):
            return UNKNOWN
        return args[0].data[offset:offset + length]
    if name == "buffer.readu8" and len(args) >= 2 and isinstance(args[0], BufferValue) and is_int(args[1]):
        if args[1] < 0 or args[1] >= len(args[0].data):
            return UNKNOWN
        return args[0].data[args[1]]
    if name == "buffer.readu32" and len(args) >= 2 and isinstance(args[0], BufferValue) and is_int(args[1]):
        if args[1] < 0 or args[1] + 4 > len(args[0].data):
            return UNKNOWN
        return int.from_bytes(args[0].data[args[1]:args[1] + 4], "little")
    if name == "bit32.bxor" and args and all(is_int(value) for value in args):
        result = 0
        for value in args:
            result ^= value & 0xFFFFFFFF
        return result & 0xFFFFFFFF
    if name == "bit32.band" and args and all(is_int(value) for value in args):
        result = 0xFFFFFFFF
        for value in args:
            result &= value & 0xFFFFFFFF
        return result & 0xFFFFFFFF
    if name == "bit32.bor" and args and all(is_int(value) for value in args):
        result = 0
        for value in args:
            result |= value & 0xFFFFFFFF
        return result & 0xFFFFFFFF
    if name == "bit32.rshift" and len(args) == 2 and is_int(args[0]) and is_int(args[1]):
        return (args[0] & 0xFFFFFFFF) >> min(31, max(0, args[1]))
    if name == "bit32.lshift" and len(args) == 2 and is_int(args[0]) and is_int(args[1]):
        return (args[0] << min(31, max(0, args[1]))) & 0xFFFFFFFF
    if name == "bit32.rrotate" and len(args) == 2 and is_int(args[0]) and is_int(args[1]):
        shift = args[1] % 32
        value = args[0] & 0xFFFFFFFF
        return ((value >> shift) | (value << (32 - shift))) & 0xFFFFFFFF if shift else value
    if name == "bit32.lrotate" and len(args) == 2 and is_int(args[0]) and is_int(args[1]):
        shift = args[1] % 32
        value = args[0] & 0xFFFFFFFF
        return ((value << shift) | (value >> (32 - shift))) & 0xFFFFFFFF if shift else value
    if name == "math.floor" and len(args) == 1 and is_number(args[0]):
        return math.floor(args[0])
    if name == "math.abs" and len(args) == 1 and is_number(args[0]):
        return abs(args[0])
    if name == "math.max" and args and all(is_number(value) for value in args):
        return max(args)
    if name == "math.min" and args and all(is_number(value) for value in args):
        return min(args)
    return UNKNOWN


def rename_bindings(root: Node, analyzer: Analyzer, stats: PassStats) -> Node:
    used_names = set(analyzer.global_names)
    for node in walk(root):
        if node.kind == "name":
            used_names.add(node.get("name", ""))
    counters = {"var": 0, "func": 0, "param": 0, "loop": 0}
    names: dict[int, str] = {}
    for binding in sorted(analyzer.bindings.values(), key=lambda item: item.order):
        if binding.name in {"_ENV", "self"}:
            continue
        if len(binding.name) > 3 and not any(character.isdigit() for character in binding.name):
            continue
        category = "param" if binding.kind == "param" else "func" if binding.kind == "localfunc" else "loop" if binding.kind == "loop" else "var"
        while True:
            index = counters[category] + 1
            counters[category] = index
            candidate = f"{category}_{index}"
            if candidate not in used_names:
                break
        used_names.add(candidate)
        names[binding.ident] = candidate
    if not names:
        return root
    for node in walk(root):
        if node.kind == "local":
            bindings = analyzer.declaration_bindings.get(id(node), [])
            for index, binding in enumerate(bindings):
                if binding.ident in names and index < len(node.get("names", [])):
                    node.fields["names"][index] = names[binding.ident]
        elif node.kind == "localfunc":
            bindings = analyzer.declaration_bindings.get(id(node), [])
            if bindings and bindings[0].ident in names:
                node.fields["name"] = names[bindings[0].ident]
        elif node.kind == "fornum":
            bindings = analyzer.loop_bindings.get(id(node), [])
            if bindings and bindings[0].ident in names:
                node.fields["var"] = names[bindings[0].ident]
        elif node.kind == "forin":
            values = node.fields.get("vars", [])
            for index, binding in enumerate(analyzer.loop_bindings.get(id(node), [])):
                if binding.ident in names and index < len(values):
                    values[index] = names[binding.ident]
        elif node.kind in {"function", "localfunc", "funcdef"}:
            for index, binding in enumerate(analyzer.parameter_bindings.get(id(node), [])):
                if binding.ident in names and index < len(node.get("params", [])):
                    node.fields["params"][index] = names[binding.ident]

    def callback(node: Node, target: bool) -> Node:
        if node.kind != "name":
            return node
        binding = binding_for(analyzer, node)
        if binding is not None and binding.ident in names:
            node.fields["name"] = names[binding.ident]
            stats.names_renamed += 1
        return node

    root.fields["body"] = transform_block(root.get("body", []), callback)
    return root
